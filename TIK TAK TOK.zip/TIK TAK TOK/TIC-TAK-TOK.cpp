#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System/Sleep.hpp>

sf::Vector2i winningLine(-1, -1);  // Initialize the winning line to default values

// Function declarations
void initializeBoard(char board[3][3]);
void printBoard(const char board[3][3], sf::RenderWindow& window, sf::Font& font);
bool makeMove(char board[3][3], int row, int col, char currentPlayer);
bool checkWin(const char board[3][3], char currentPlayer);
bool checkDraw(const char board[3][3]);
bool isBoardFull(const char board[3][3]);
bool playAgainstComputer(char board[3][3], char player, const std::string& difficulty);
void makeComputerMoveEasy(char board[3][3], char player);
void makeComputerMoveMedium(char board[3][3], char player);
void makeComputerMoveHard(char board[3][3], char player);
int minimax(char board[3][3], int depth, bool isMaximizing, char player);

int main() {
start:
    char board[3][3];
    char currentPlayer = 'X';
    char playagain;

    sf::RenderWindow window(sf::VideoMode(300, 300), "Tic Tac Toe");
    sf::Font font;
    if (!font.loadFromFile("ariel.ttf")) {
        std::cerr << "Error loading font file. Using default font.\n";
        return 1;
    }

    sf::SoundBuffer buffer;
    if (!buffer.loadFromFile("click.wav")) {
        std::cerr << "Error loading sound file.\n";
        return 1;
    }

    sf::Sound sound;
    sound.setBuffer(buffer);

    do {
        initializeBoard(board);

        std::cout << "Do you want to play multiplayer? (y/n): ";
        char choice;
        std::cin >> choice;

        if (choice == 'y' || choice == 'Y') {
            std::cout << "You chose multiplayer.\n";

            while (!isBoardFull(board)) {
                window.clear(sf::Color::Black);
                printBoard(board, window, font);

                sf::Event event;
                while (window.pollEvent(event)) {
                    if (event.type == sf::Event::Closed) {
                        window.close();
                        return 0;
                    }

                    if (event.type == sf::Event::MouseButtonPressed) {
                        if (event.mouseButton.button == sf::Mouse::Left) {
                            int col = event.mouseButton.x / 100;
                            int row = event.mouseButton.y / 100;

                            if (makeMove(board, row, col, currentPlayer)) {
                                sound.play();

                                if (checkWin(board, currentPlayer)) {
                                    std::cout << "Player " << currentPlayer << " wins!\n";
                                    sf::sleep(sf::milliseconds(2000));

                                    while (window.isOpen()) {
                                        sf::Event event;
                                        while (window.pollEvent(event)) {
                                            if (event.type == sf::Event::Closed) {
                                                window.close();
                                                return 0;
                                            }
                                        }
                                    }
                                }

                                if (checkDraw(board)) {
                                    std::cout << "It's a draw!\n";
                                    window.close();
                                    return 0;
                                }

                                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                            }
                        }
                    }
                }

                window.display();
            }
        }
        else {
            std::cout << "You chose to play against the computer.\n";
            std::string difficulty;
            std::cout << "Select difficulty level (easy/medium/hard): ";
            std::cin >> difficulty;

            while (!isBoardFull(board)) {
                window.clear(sf::Color::Black);
                printBoard(board, window, font);

                sf::Event event;
                while (window.pollEvent(event)) {
                    if (event.type == sf::Event::Closed) {
                        window.close();
                        return 0;
                    }

                    if (event.type == sf::Event::MouseButtonPressed) {
                        if (event.mouseButton.button == sf::Mouse::Left) {
                            int col = event.mouseButton.x / 100;
                            int row = event.mouseButton.y / 100;

                            if (makeMove(board, row, col, currentPlayer)) {
                                sound.play();

                                if (checkWin(board, currentPlayer)) {
                                    std::cout << "Player " << currentPlayer << " wins!\n";
                                    sf::sleep(sf::milliseconds(2000));

                                    while (window.isOpen()) {
                                        sf::Event event;
                                        while (window.pollEvent(event)) {
                                            if (event.type == sf::Event::Closed) {
                                                window.close();
                                                return 0;
                                            }
                                        }
                                    }
                                }

                                if (checkDraw(board)) {
                                    std::cout << "It's a draw!\n";
                                    window.close();
                                    return 0;
                                }

                                currentPlayer = 'O';
                            }
                        }
                    }
                }

                if (currentPlayer == 'O') {
                    if (playAgainstComputer(board, currentPlayer, difficulty)) {
                        sound.play();

                        if (checkWin(board, currentPlayer)) {
                            std::cout << "Computer wins!\n";
                            sf::sleep(sf::milliseconds(2000));

                            while (window.isOpen()) {
                                sf::Event event;
                                while (window.pollEvent(event)) {
                                    if (event.type == sf::Event::Closed) {
                                        window.close();
                                        return 0;
                                    }
                                }
                            }
                        }

                        if (checkDraw(board)) {
                            std::cout << "It's a draw!\n";
                            window.close();
                            return 0;
                        }

                        currentPlayer = 'X';
                    }
                }

                window.display();
            }
        }
        std::cout << "Do you want to play again?(y/n): ";
        std::cin >> playagain;
        std::cout << std::endl;
        if (playagain == 'y' || playagain == 'Y') {
            goto start;
        }
        else {
            break;
        }


    } while (true);

    window.close();

    return 0;
}




void initializeBoard(char board[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            board[i][j] = ' ';
        }
    }
}

// Function to print the Tic Tac Toe board with the winning line
void printBoard(const char board[3][3], sf::RenderWindow& window, sf::Font& font) {
    // Draw the Tic Tac Toe board using SFML shapes (rectangles)
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            sf::RectangleShape square(sf::Vector2f(100, 100));
            square.setPosition(j * 100, i * 100);
            square.setOutlineThickness(2);
            square.setOutlineColor(sf::Color::White);
            square.setFillColor(sf::Color::Black); // Fill the square with black color

            window.draw(square);

            // Draw 'X' or 'O' in the square
            if (board[i][j] == 'X' || board[i][j] == 'O') {
                sf::Text text(board[i][j] == 'X' ? "X" : "O", font, 50);
                text.setPosition(j * 100 + 25, i * 100 + 10);
                text.setFillColor(sf::Color::White); // Set text color to white
                window.draw(text);
            }
        }
    }

    // Draw the winning line if there is a winner
    if (winningLine.x != -1) {
        sf::Vertex line[2];

        if (winningLine.y == -1) {
            // Horizontal line
            line[0].position = sf::Vector2f(0, winningLine.x * 100 + 50);
            line[1].position = sf::Vector2f(300, winningLine.x * 100 + 50);
        }
        else if (winningLine.x == -1) {
            // Vertical line
            line[0].position = sf::Vector2f(winningLine.y * 100 + 50, 0);
            line[1].position = sf::Vector2f(winningLine.y * 100 + 50, 300);
        }
        else {
            // Diagonal line
            if (winningLine.x == 0 && winningLine.y == 0) {
                line[0].position = sf::Vector2f(0, 0);
                line[1].position = sf::Vector2f(300, 300);
            }
            else {
                line[0].position = sf::Vector2f(300, 0);
                line[1].position = sf::Vector2f(0, 300);
            }
        }

        for (int i = 0; i < 2; ++i) {
            line[i].color = sf::Color::Green;
        }

        window.draw(line, 2, sf::Lines);
    }
}




bool makeMove(char board[3][3], int row, int col, char currentPlayer) {
    if (row < 0 || row >= 3 || col < 0 || col >= 3 || board[row][col] != ' ') {
        return false;
    }

    board[row][col] = currentPlayer;
    return true;
}

bool checkWin(const char board[3][3], char currentPlayer) {
    // Check rows, columns, and diagonals for a win
    for (int i = 0; i < 3; ++i) {
        if (board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer) {
            winningLine = sf::Vector2i(i, -1); // Horizontal line
            return true;
        }
        if (board[0][i] == currentPlayer && board[1][i] == currentPlayer && board[2][i] == currentPlayer) {
            winningLine = sf::Vector2i(-1, i); // Vertical line
            return true;
        }
    }

    if (board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) {
        winningLine = sf::Vector2i(-1, -1); // Diagonal line (top-left to bottom-right)
        return true;
    }
    if (board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer) {
        winningLine = sf::Vector2i(-1, -1); // Diagonal line (top-right to bottom-left)
        return true;
    }

    winningLine = sf::Vector2i(-1, -1); // No winning line
    return false;
}


bool checkDraw(const char board[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                return false;
            }
        }
    }

    return true;
}

bool isBoardFull(const char board[3][3]) {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                return false;
            }
        }
    }

    return true;
}

bool playAgainstComputer(char board[3][3], char player, const std::string& difficulty) {
    if (difficulty == "easy") {
        makeComputerMoveEasy(board, player);
    }
    else if (difficulty == "medium") {
        makeComputerMoveMedium(board, player);
    }
    else if (difficulty == "hard") {
        makeComputerMoveHard(board, player);
    }
    else {
        std::cerr << "Invalid difficulty level.\n";
        return false;
    }

    return true;
}

void makeComputerMoveEasy(char board[3][3], char player) {
    int row, col;
    do {
        row = rand() % 3;
        col = rand() % 3;
    } while (board[row][col] != ' ');
    makeMove(board, row, col, player);
}

void makeComputerMoveMedium(char board[3][3], char player) {
    // Basic blocking strategy: Block the opponent if they are about to win
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                board[i][j] = player;
                if (checkWin(board, player)) {
                    return;
                }
                board[i][j] = ' ';
            }
        }
    }

    // If no immediate winning move for the opponent, make a random move
    makeComputerMoveEasy(board, player);
}

void makeComputerMoveHard(char board[3][3], char player) {
    int bestScore = INT_MIN;
    int bestMoveRow = -1;
    int bestMoveCol = -1;

    // Loop through all empty cells and find the best move using Minimax
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (board[i][j] == ' ') {
                board[i][j] = player;
                int score = minimax(board, 0, false, player);
                board[i][j] = ' ';

                if (score > bestScore) {
                    bestScore = score;
                    bestMoveRow = i;
                    bestMoveCol = j;
                }
            }
        }
    }

    // Make the best move
    makeMove(board, bestMoveRow, bestMoveCol, player);
}

int minimax(char board[3][3], int depth, bool isMaximizing, char player) {
    // Evaluate the score of the current board state
    int score = 0;
    if (checkWin(board, 'X')) {
        score = -1; // Player wins
    }
    else if (checkWin(board, 'O')) {
        score = 1; // Computer wins
    }
    else if (checkDraw(board)) {
        score = 0; // Draw
    }

    // If the game is over, return the score
    if (score != 0) {
        return score;
    }

    // If not, continue exploring possible moves using Minimax
    if (isMaximizing) {
        int bestScore = INT_MIN;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (board[i][j] == ' ') {
                    board[i][j] = player;
                    int currentScore = minimax(board, depth + 1, true, player);
                    board[i][j] = ' ';
                    bestScore = std::min(bestScore, currentScore);
                }
            }
        }
        return bestScore;
    }
}